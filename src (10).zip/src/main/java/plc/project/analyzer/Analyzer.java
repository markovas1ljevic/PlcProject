package plc.project.analyzer;

import plc.project.parser.Ast;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Optional;
import java.util.List;

public final class Analyzer implements Ast.Visitor<Ir, AnalyzeException> {

    private Scope scope;

    public Analyzer(Scope scope) {
        this.scope = scope;
    }

    @Override
    public Ir.Source visit(Ast.Source ast) throws AnalyzeException {
        var statements = new ArrayList<Ir.Stmt>();
        for (var statement : ast.statements()) {
            statements.add(visit(statement));
        }
        return new Ir.Source(statements);
    }

    private Ir.Stmt visit(Ast.Stmt ast) throws AnalyzeException {
        return (Ir.Stmt) visit((Ast) ast); //helper to cast visit(Ast.Stmt) to Ir.Stmt
    }

    @Override
    public Ir.Stmt.Let visit(Ast.Stmt.Let ast) throws AnalyzeException {
        Optional<Ir.Expr> value = ast.value().isPresent()
                ? Optional.of(visit(ast.value().get()))
                : Optional.empty();
        if (scope.get(ast.name(), true).isPresent()) {
            throw new AnalyzeException("Variable " + ast.name() + " is already defined.");
        }
        scope.define(ast.name(), Type.ANY);
        return new Ir.Stmt.Let(ast.name(), Type.ANY, value);
    }


    @Override
    public Ir.Stmt.Def visit(Ast.Stmt.Def ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public Ir.Stmt.If visit(Ast.Stmt.If ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public Ir.Stmt.For visit(Ast.Stmt.For ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public Ir.Stmt.Return visit(Ast.Stmt.Return ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public Ir.Stmt.Expression visit(Ast.Stmt.Expression ast) throws AnalyzeException {
        var expression = visit(ast.expression());
        return new Ir.Stmt.Expression(expression);
    }

    @Override
    public Ir.Stmt.Assignment visit(Ast.Stmt.Assignment ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    private Ir.Expr visit(Ast.Expr ast) throws AnalyzeException {
        return (Ir.Expr) visit((Ast) ast); //helper to cast visit(Ast.Expr) to Ir.Expr
    }

    @Override
    public Ir.Expr.Literal visit(Ast.Expr.Literal ast) throws AnalyzeException {
        var type = switch (ast.value()) {
            case null -> Type.NIL;
            case Boolean _ -> Type.BOOLEAN;
            case BigInteger _ -> Type.INTEGER;
            case BigDecimal _ -> Type.DECIMAL;
            case String _ -> Type.STRING;

            default -> throw new AssertionError(ast.value().getClass());
        };
        return new Ir.Expr.Literal(ast.value(), type);
    }

    @Override
    public Ir.Expr.Group visit(Ast.Expr.Group ast) throws AnalyzeException {
        // analyze the contained expression
        Ir.Expr expression = visit(ast.expression());

        // create and return a new group expr with the analyzed inner expr
        // and use the type of the inner expr
        return new Ir.Expr.Group(expression);
    }

    @Override
    public Ir.Expr.Binary visit(Ast.Expr.Binary ast) throws AnalyzeException {
        // visit the left and right operands, obtaining Ir expression values
        Ir.Expr left = (Ir.Expr) visit(ast.left());
        Ir.Expr right = (Ir.Expr) visit(ast.right());

        // get the operator
        String operator = ast.operator();

        // determine the result type based on operator types
        Type resultType = determineResultType(operator, left.type(), right.type());

        // create and return a new Ir.Expr.Binary
        return new Ir.Expr.Binary(operator, left, right, resultType);
    }

    // helper method to determine the result type
    private Type determineResultType(String operator, Type leftType, Type rightType) throws AnalyzeException {
        // handling for logical operators (AND, OR)
        if (operator.equals("&&") || operator.equals("||")) {
            // check that both operands are boolean
            if (leftType.equals(Type.BOOLEAN) && rightType.equals(Type.BOOLEAN)) {
                return Type.BOOLEAN;
            }
            throw new AnalyzeException("Logical operators require boolean operands");
        }

        // handling for comparison operators (==, !=)
        else if (operator.equals("==") || operator.equals("!=")) {

            return Type.BOOLEAN;
        }

        // handling relational operators (<, <=, >, >=)
        else if (operator.equals("<") || operator.equals("<=") ||
                operator.equals(">") || operator.equals(">=")) {
            // check that both operands are comparable (usually number types)
            if (leftType.equals(Type.INTEGER) && rightType.equals(Type.INTEGER) ||
                    leftType.equals(Type.DECIMAL) && rightType.equals(Type.DECIMAL)) {
                return Type.BOOLEAN;
            }
            throw new AnalyzeException("Relational operators require numeric operands of matching types");
        }

        // for arithmetic operators (+, -, *, /, %)
        else if (operator.equals("+") || operator.equals("-") ||
                operator.equals("*") || operator.equals("/") ||
                operator.equals("%")) {
            // string concat with +
            if (operator.equals("+") && (leftType.equals(Type.STRING) || rightType.equals(Type.STRING))) {
                return Type.STRING;
            }

            // integer arithmetic
            if (leftType.equals(Type.INTEGER) && rightType.equals(Type.INTEGER)) {
                return Type.INTEGER;
            }

            // decimal arithmetic
            if (leftType.equals(Type.DECIMAL) && rightType.equals(Type.DECIMAL)) {
                return Type.DECIMAL;
            }

            throw new AnalyzeException("Arithmetic operators require matching numeric operands");
        }

        // handling unknown operators
        throw new AnalyzeException("Unknown binary operator: " + operator);
    }

    @Override
    public Ir.Expr.Variable visit(Ast.Expr.Variable ast) throws AnalyzeException {
        var type = scope.get(ast.name(), false)
        .orElseThrow(() -> new AnalyzeException("Variable" + ast.name() + " is not defined."));
        return new Ir.Expr.Variable(ast.name(), (type));
    }

    @Override
    public Ir.Expr.Property visit(Ast.Expr.Property ast) throws AnalyzeException {
        // analyze receiver expr
        Ir.Expr receiver = visit(ast.receiver());

        // ensure the receiver is of Type.Object
        if (!(receiver.type() instanceof Type.Object objectType)) {
            throw new AnalyzeException("Receiver must be of type Object.");
        }

        // ensure the property is defined in the object's field scope
        var propertyType = objectType.scope().get(ast.name(), true);
        if (propertyType == null) {
            throw new AnalyzeException("Property '" + ast.name() + "' is not defined in the object.");
        }

        // return the new expr with the resolved property type (im goated)
        return new Ir.Expr.Property(receiver, ast.name(), Type.STRING);
    }


    @Override
    public Ir.Expr.Function visit(Ast.Expr.Function ast) throws AnalyzeException {
        // check if the function is defined
        Type type = scope.get(ast.name(), true)
                .orElseThrow(() -> new AnalyzeException("Function '" + ast.name() + "' is not defined."));

        // check that the type is a function
        if (!(type instanceof Type.Function functionType)) {
            throw new AnalyzeException("Symbol '" + ast.name() + "' is not a function.");
        }

        // analyze arguments
        List<Ir.Expr> arguments = new ArrayList<>();
        for (Ast.Expr argument : ast.arguments()) {
            arguments.add(visit(argument));
        }

        // ensure argument count matches parameter count
        if (arguments.size() != functionType.parameters().size()) {
            throw new AnalyzeException("Incorrect number of arguments for function '" + ast.name() + "'.");
        }

        // check each argument against its parameter
        for (int i = 0; i < arguments.size(); i++) {
            requireSubtype(arguments.get(i).type(), functionType.parameters().get(i));
        }

        // return the expression
        return new Ir.Expr.Function(ast.name(), arguments, functionType.returns());
    }



    @Override
    public Ir.Expr.Method visit(Ast.Expr.Method ast) throws AnalyzeException {
        Ir.Expr receiver = visit(ast.receiver());

        if (!(receiver.type() instanceof Type.Object objectType)) {
            throw new AnalyzeException("Receiver must be of type Object.");
        }

        // get method type
        var methodTypeOpt = objectType.scope().get(ast.name(), true);
        if (methodTypeOpt.isEmpty() || !(methodTypeOpt.get() instanceof Type.Function methodType)) {
            throw new AnalyzeException("Method '" + ast.name() + "' is not defined or is not a function.");
        }

        // check arguments
        var args = new ArrayList<Ir.Expr>();
        for (var expr : ast.arguments()) {
            args.add(visit(expr));
        }

        // check argument count
        if (methodType.parameters().size() != args.size()) {
            throw new AnalyzeException("Argument count mismatch for method '" + ast.name() + "'");
        }

        // check argument types
        for (int i = 0; i < args.size(); i++) {
            requireSubtype(args.get(i).type(), methodType.parameters().get(i));
        }

        return new Ir.Expr.Method(receiver, ast.name(), args, methodType.returns());
    }


    @Override
    public Ir.Expr.ObjectExpr visit(Ast.Expr.ObjectExpr ast) throws AnalyzeException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    public static void requireSubtype(Type type, Type other) throws AnalyzeException {
        if (type.equals(other) || other.equals(Type.ANY)) {
            return;
        }

        // subtypes of equatable
        if (type.equals(Type.NIL) && other.equals(Type.EQUATABLE)) {
            return;
        }

        // subtypes of equatable
        if (type.equals(Type.COMPARABLE) && other.equals(Type.EQUATABLE)) {
            return;
        }

        // subtypes of equatable
        if (type.equals(Type.ITERABLE) && other.equals(Type.EQUATABLE)) {
            return;
        }

        // subtypes of Comparable: Boolean, Integer, Decimal, String
        if (other.equals(Type.COMPARABLE) &&
                (type.equals(Type.BOOLEAN) ||
                        type.equals(Type.INTEGER) ||
                        type.equals(Type.DECIMAL) ||
                        type.equals(Type.STRING))) {
            return;
        }

        // otherwise, not a valid subtype
        throw new AnalyzeException(type + " is not a subtype of " + other);
    }

}
