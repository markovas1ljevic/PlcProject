package plc.project.parser;

import plc.project.lexer.Token;

import java.util.List;

import java.util.ArrayList;

import java.math.BigDecimal;
import java.math.BigInteger;

import static com.google.common.base.Preconditions.checkState;

/**
 * This style of parser is called <em>recursive descent</em>. Each rule in our
 * grammar has dedicated function, and references to other rules correspond to
 * calling that function. Recursive rules are therefore supported by actual
 * recursive calls, while operator precedence is encoded via the grammar.
 *
 * <p>The parser has a similar architecture to the lexer, just with
 * {@link Token}s instead of characters. As before, {@link TokenStream#peek} and
 * {@link TokenStream#match} help with traversing the token stream. Instead of
 * emitting tokens, you will instead need to extract the literal value via
 * {@link TokenStream#get} to be added to the relevant AST.
 */
public final class Parser {

    private final TokenStream tokens;

    public Parser(List<Token> tokens) {
        this.tokens = new TokenStream(tokens);
    }

    public Ast.Source parseSource() throws ParseException {
        List<Ast.Stmt> statements = new ArrayList<>(); // create a list to store statements

        // parse until token stream is empty
        while (tokens.has(0)) {
            statements.add(parseStmt());
        }

        return new Ast.Source(statements); //TODO
    }

    public Ast.Stmt parseStmt() throws ParseException {
        if (tokens.match("LET")) {
            return parseLetStmt();
        } else if (tokens.match("DEF")) {
            return parseDefStmt();
        } else if (tokens.match("IF")) {
            return parseIfStmt();
        } else if (tokens.match("FOR")) {
            return parseForStmt();
        } else if (tokens.match("RETURN")) {
            return parseReturnStmt();
        } else {
            return parseExpressionOrAssignmentStmt();
        }
    }


    private Ast.Stmt.Let parseLetStmt() throws ParseException {
        throw new ParseException("Invalid 'let' statement");
    }

    private Ast.Stmt.Def parseDefStmt() throws ParseException {
        throw new ParseException("Invalid 'def' statement");
    }

    private Ast.Stmt.If parseIfStmt() throws ParseException {
        throw new ParseException("Invalid 'if' statement");
    }

    private Ast.Stmt.For parseForStmt() throws ParseException {
        throw new ParseException("Invalid 'for' statement");
    }

    private Ast.Stmt.Return parseReturnStmt() throws ParseException {
        throw new ParseException("Invalid 'return' statement");
    }

    private Ast.Stmt parseExpressionOrAssignmentStmt() throws ParseException {

        throw new ParseException("Invalid expression or assignment statement");
    }


    public Ast.Expr parseExpr() throws ParseException {
        return parseLogicalExpr();
    }

    private Ast.Expr parseLogicalExpr() throws ParseException {
        Ast.Expr expr = parseComparisonExpr();
        while (tokens.peek("AND") || tokens.peek("OR")) {
            String operator = tokens.get(0).literal();
            tokens.match(operator);
            Ast.Expr right = parseComparisonExpr();
            expr = new Ast.Expr.Binary(operator, expr, right);
        }
        return expr;
    }

    private Ast.Expr parseComparisonExpr() throws ParseException {
        Ast.Expr expr = parseAdditiveExpr();
        while (tokens.peek("==") || tokens.peek("!=") || tokens.peek("<") || tokens.peek(">") || tokens.peek("<=") || tokens.peek(">=")) {
            String operator = tokens.get(0).literal();
            tokens.match(operator);
            Ast.Expr right = parseAdditiveExpr();
            expr = new Ast.Expr.Binary(operator, expr, right);
        }
        return expr;
    }

    private Ast.Expr parseAdditiveExpr() throws ParseException {
        Ast.Expr expr = parseMultiplicativeExpr();
        while (tokens.peek("+") || tokens.peek("-")) {
            String operator = tokens.get(0).literal();
            tokens.match(operator);
            Ast.Expr right = parseMultiplicativeExpr();
            expr = new Ast.Expr.Binary(operator, expr, right);
        }
        return expr;
    }

    private Ast.Expr parseMultiplicativeExpr() throws ParseException {
        Ast.Expr expr = parseSecondaryExpr();
        while (tokens.peek("*") || tokens.peek("/")) {
            String operator = tokens.get(0).literal();
            tokens.match(operator);
            Ast.Expr right = parseSecondaryExpr();
            expr = new Ast.Expr.Binary(operator, expr, right);
        }
        return expr;
    }

    private Ast.Expr parseSecondaryExpr() throws ParseException {
        Ast.Expr expr = parsePrimaryExpr();

        while (tokens.match(".")) {
            if (tokens.match(Token.Type.IDENTIFIER)) {
                String name = tokens.get(-1).literal();
                if (tokens.match("(")) { // use match to for parentheses and advance tokenstream
                    List<Ast.Expr> arguments = new ArrayList<>();
                    if (!tokens.peek(")")) { // check for arguments
                        do {
                            arguments.add(parseExpr());
                        } while (tokens.match(","));
                    }
                    tokens.match(")");
                    expr = new Ast.Expr.Method(expr, name, arguments); // create method
                } else { // access the property
                    expr = new Ast.Expr.Property(expr, name);
                }
            } else {
                throw new ParseException("Expected identifier after '.'");
            }
        }
        return expr;
    }




    private Ast.Expr parsePrimaryExpr() throws ParseException {
        if (tokens.peek(Token.Type.INTEGER)) {
            // parse int literal
            BigInteger value = new BigInteger(tokens.get(0).literal());
            tokens.match(Token.Type.INTEGER);
            return new Ast.Expr.Literal(value);
        }
        else if (tokens.peek(Token.Type.DECIMAL)) {
            // parse decimal
            BigDecimal value = new BigDecimal(tokens.get(0).literal());
            tokens.match(Token.Type.DECIMAL);
            return new Ast.Expr.Literal(value);
        }
        else if (tokens.peek(Token.Type.STRING)) {
            // parse string
            String literal = tokens.get(0).literal();
            tokens.match(Token.Type.STRING);
            return new Ast.Expr.Literal(literal);
        }
        else if (tokens.peek("TRUE") || tokens.peek("FALSE")) {
            // parse bool
            Boolean value = Boolean.parseBoolean(tokens.get(0).literal());
            tokens.match(tokens.get(0).literal());
            return new Ast.Expr.Literal(value);
        }
        else if (tokens.peek("(")) {
            // return group expr
            return parseGroupExpr();
        }
        else if (tokens.peek(Token.Type.IDENTIFIER)) {
            // parse variable or function call
            return parseVariableOrFunctionExpr();
        }

        throw new ParseException("Invalid primary expression");
    }


    private Ast.Expr.Literal parseLiteralExpr() throws ParseException {
        if (tokens.match(Token.Type.INTEGER)) {
            // return int literal
            return new Ast.Expr.Literal(new BigInteger(tokens.get(-1).literal()));
        }
        else if (tokens.match(Token.Type.DECIMAL)) {
            // return decimal
            return new Ast.Expr.Literal(new BigDecimal(tokens.get(-1).literal()));
        }
        else if (tokens.match(Token.Type.STRING)) {
            // parse string
            String literal = tokens.get(-1).literal();
            return new Ast.Expr.Literal(literal.substring(1, literal.length() - 1));
        }
        else if (tokens.match("TRUE")) {
            return new Ast.Expr.Literal(true);
        }
        else if (tokens.match("FALSE")) {
            return new Ast.Expr.Literal(false);
        }
        else if (tokens.match("NULL")) {
            return new Ast.Expr.Literal(null);
        }

        throw new ParseException("Invalid literal expression.");
    }


    private Ast.Expr.Group parseGroupExpr() throws ParseException {
        if (tokens.match("(")) {
            Ast.Expr expr = parseExpr();
            if (tokens.match(")")) {
                return new Ast.Expr.Group(expr);
            }
        }
        throw new ParseException("Invalid group expression");
    }

    private Ast.Expr.ObjectExpr parseObjectExpr() throws ParseException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    private Ast.Expr parseVariableOrFunctionExpr() throws ParseException {
        if (tokens.peek(Token.Type.IDENTIFIER)) {
            String name = tokens.get(0).literal();
            tokens.match(name);
            if (tokens.match("(")) {
                List<Ast.Expr> arguments = new ArrayList<>();
                while (!tokens.match(")")) {
                    arguments.add(parseExpr());
                    tokens.match(",");
                }
                return new Ast.Expr.Function(name, arguments);
            }
            return new Ast.Expr.Variable(name);
        }
        throw new ParseException("Invalid variable or function expression");
    }


    private static final class TokenStream {

        private final List<Token> tokens;
        private int index = 0;

        private TokenStream(List<Token> tokens) {
            this.tokens = tokens;
        }

        /**
         * Returns true if there is a token at (index + offset).
         */
        public boolean has(int offset) {
            return index + offset < tokens.size();
        }

        /**
         * Returns the token at (index + offset).
         */
        public Token get(int offset) {
            checkState(has(offset));
            return tokens.get(index + offset);
        }

        /**
         * Returns true if the next characters match their corresponding
         * pattern. Each pattern is either a {@link Token.Type}, matching tokens
         * of that type, or a {@link String}, matching tokens with that literal.
         * In effect, {@code new Token(Token.Type.IDENTIFIER, "literal")} is
         * matched by both {@code peek(Token.Type.IDENTIFIER)} and
         * {@code peek("literal")}.
         */
        public boolean peek(Object... patterns) {
            if (!has(patterns.length - 1)) {
                return false;
            }
            for (int offset = 0; offset < patterns.length; offset++) {
                var token = tokens.get(index + offset);
                var pattern = patterns[offset];
                checkState(pattern instanceof Token.Type || pattern instanceof String, pattern);
                if (!token.type().equals(pattern) && !token.literal().equals(pattern)) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Equivalent to peek, but also advances the token stream.
         */
        public boolean match(Object... patterns) {
            var peek = peek(patterns);
            if (peek) {
                index += patterns.length;
            }
            return peek;
        }

    }

}
