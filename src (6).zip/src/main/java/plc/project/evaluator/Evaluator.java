package plc.project.evaluator;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import plc.project.parser.Ast;
import java.util.HashMap;
import java.util.Map;



public final class Evaluator implements Ast.Visitor<RuntimeValue, EvaluateException> {

    private Scope scope;
    // trying to use a hashmap to resolve runtime inconsistency
    private final Map<String, RuntimeValue.Primitive> primitiveCache = new HashMap<>();
    public Evaluator(Scope scope) {
        this.scope = scope;
    }

    @Override
    public RuntimeValue visit(Ast.Source ast) throws EvaluateException {
        RuntimeValue value = new RuntimeValue.Primitive(null);
        for (var stmt : ast.statements()) {
            value = visit(stmt);
        }
        //TODO: Handle the possibility of RETURN being called outside of a function.
        return value;
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.Let ast) throws EvaluateException {
        // check if the variable is already defined
        if (scope.get(ast.name(), true).isPresent()) {
            throw new EvaluateException("Variable '" + ast.name() + "' is already defined in this scope.");
        }

        // print debug
        System.out.println("Evaluating assignment for: " + ast.name());
        ast.value().ifPresent(value -> System.out.println("Expression Type: " + value));

        // evaluate the right side
        RuntimeValue value;
        try {
            value = ast.value().isPresent() ? visit(ast.value().get()) : new RuntimeValue.Primitive(null);
        } catch (UnsupportedOperationException e) {
            System.out.println("Unhandled expression type: " + ast.value().get());
            value = new RuntimeValue.Primitive(null);
        }

        // define the variable in scope
        scope.define(ast.name(), value);

        return value;
    }





    @Override
    public RuntimeValue visit(Ast.Stmt.Def ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.If ast) throws EvaluateException {
        // evaluate the condition using runtimevalue
        RuntimeValue condition = visit(ast.condition());
        boolean conditionValue = requireType(condition, Boolean.class);

        // create a new scope for the if statement
        Scope newScope = new Scope(scope);

        RuntimeValue result = new RuntimeValue.Primitive(null); // def return value

        try {
            if (conditionValue) {
                for (Ast.Stmt stmt : ast.thenBody()) {  
                    result = visit(stmt);
                }
            } else if (!ast.elseBody().isEmpty()) { // check if elseBody is non-empty
                for (Ast.Stmt stmt : ast.elseBody()) {
                    result = visit(stmt);
                }
            }
        } finally {
            // restore the original scope if needed (handled by scope hierarchy)
        }

        return result;
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.For ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.Return ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.Expression ast) throws EvaluateException {
        return visit(ast.expression());
    }

    @Override
    public RuntimeValue visit(Ast.Stmt.Assignment ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public RuntimeValue visit(Ast.Expr.Literal ast) throws EvaluateException {
        return new RuntimeValue.Primitive(ast.value());
    }

    @Override

    public RuntimeValue visit(Ast.Expr.Group ast) throws EvaluateException {
        // validate there is an inner expression
        if (ast.expression() == null) {
            throw new EvaluateException("Group expression is missing.");
        }

        // return the contained expression
        return visit(ast.expression());
    }




    @Override
    public RuntimeValue visit(Ast.Expr.Binary ast) throws EvaluateException {
        // evaluate left and right operands
        RuntimeValue leftValue = visit(ast.left());
        RuntimeValue rightValue = visit(ast.right());
        String operator = ast.operator();

        // ensure both operands are primitive values
        if (!(leftValue instanceof RuntimeValue.Primitive) || !(rightValue instanceof RuntimeValue.Primitive)) {
            throw new EvaluateException("Operands must be primitive values.");
        }

        Object left = ((RuntimeValue.Primitive) leftValue).value();
        Object right = ((RuntimeValue.Primitive) rightValue).value();



        // handle string concatenation
        if (operator.equals("+") && (left instanceof String || right instanceof String)) {
            return getCachedPrimitive(left.toString() + right.toString());
        }

        // logical operations
        if (left instanceof Boolean && right instanceof Boolean) {
            Boolean leftBool = (Boolean) left;
            Boolean rightBool = (Boolean) right;

            switch (operator) {
                case "AND": return getCachedPrimitive(leftBool && rightBool);
                case "OR": return getCachedPrimitive(leftBool || rightBool);
            }
        }

        // handle arithmetic operations
        if (left instanceof Number && right instanceof Number) {
            BigDecimal leftNum = new BigDecimal(left.toString()); // convert to BigDecimal
            BigDecimal rightNum = new BigDecimal(right.toString());

            switch (operator) {
                case "+":
                    return getCachedPrimitive(leftNum.add(rightNum));
                case "-":
                    return getCachedPrimitive(leftNum.subtract(rightNum));
                case "*":
                    return getCachedPrimitive(leftNum.multiply(rightNum));
                case "/":
                    if (rightNum.compareTo(BigDecimal.ZERO) == 0) {
                        throw new EvaluateException("Division by zero.");
                    }
                    // use HALF_EVEN rounding mode
                    return getCachedPrimitive(leftNum.divide(rightNum, RoundingMode.HALF_EVEN));
            }
        }

        // handle comparison operations
        if (operator.equals("==")) return getCachedPrimitive(left.equals(right));
        if (operator.equals("!=")) return getCachedPrimitive(!left.equals(right));

        if (left instanceof Number && right instanceof Number) {
            double leftNum = ((Number) left).doubleValue();
            double rightNum = ((Number) right).doubleValue();

            switch (operator) {
                case "<": return getCachedPrimitive(leftNum < rightNum);
                case "<=": return getCachedPrimitive(leftNum <= rightNum);
                case ">": return getCachedPrimitive(leftNum > rightNum);
                case ">=": return getCachedPrimitive(leftNum >= rightNum);
            }
        }

        throw new EvaluateException("Invalid operation: " + left + " " + operator + " " + right);
    }
    /*
      attempts to return a cached RuntimeValue.Primitive instance for the given value.
      If no cached instance exists, a new one is created.
     */
    private RuntimeValue.Primitive getCachedPrimitive(Object value) {
        String key = value != null ? value.toString() : "null"; // use the string representation as the key
        return primitiveCache.computeIfAbsent(key, k -> new RuntimeValue.Primitive(value));
    }



    @Override
    public RuntimeValue visit(Ast.Expr.Variable ast) throws EvaluateException {
        String variableName = ast.name();

        //  get the variable from scope
        Optional<RuntimeValue> value = scope.get(variableName, false);

        // if the variable is not found, throw an exception
        if (value.isEmpty()) {
            throw new EvaluateException("Undefined variable: " + variableName);
        }

        // return the retrieved value
        return value.get();
    }


    @Override
    public RuntimeValue visit(Ast.Expr.Property ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override

    public RuntimeValue visit(Ast.Expr.Function ast) throws EvaluateException {
        // retrieve the function from the scope
        Optional<RuntimeValue> functionOpt = scope.get(ast.name(), false);

        if (functionOpt.isEmpty()) {
            throw new EvaluateException("Undefined function: " + ast.name());
        }

        RuntimeValue functionValue = functionOpt.get();

        // ensure it is a function
        if (!(functionValue instanceof RuntimeValue.Function function)) {
            throw new EvaluateException("Variable '" + ast.name() + "' is not a function.");
        }

        // evaluate all arguments
        List<RuntimeValue> arguments = new ArrayList<>();
        for (Ast.Expr arg : ast.arguments()) {
            arguments.add(visit(arg));
        }

        // use invoke on the function with the evaluated arguments
        return function.definition().invoke(arguments);
    }


    @Override
    public RuntimeValue visit(Ast.Expr.Method ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    @Override
    public RuntimeValue visit(Ast.Expr.ObjectExpr ast) throws EvaluateException {
        throw new UnsupportedOperationException("TODO"); //TODO
    }

    /**
     * Helper function for extracting RuntimeValues of specific types. If the
     * type is subclass of {@link RuntimeValue} the check applies to the value
     * itself, otherwise the value is expected to be a {@link RuntimeValue.Primitive}
     * and the check applies to the primitive value.
     */
    private static <T> T requireType(RuntimeValue value, Class<T> type) throws EvaluateException {
        //To be discussed in lecture 3/5.
        if (RuntimeValue.class.isAssignableFrom(type)) {
            if (!type.isInstance(value)) {
                throw new EvaluateException("Expected value to be of type " + type + ", received " + value.getClass() + ".");
            }
            return (T) value;
        } else {
            var primitive = requireType(value, RuntimeValue.Primitive.class);
            if (!type.isInstance(primitive.value())) {
                var received = primitive.value() != null ? primitive.value().getClass() : null;
                throw new EvaluateException("Expected value to be of type " + type + ", received " + received + ".");
            }
            return (T) primitive.value();
        }
    }

}
